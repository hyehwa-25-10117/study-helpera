import React from "react";
import ReactDOM from "react-dom/client";
import BKTSimulator from "./BKTSimulator.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BKTSimulator />
  </React.StrictMode>
);
