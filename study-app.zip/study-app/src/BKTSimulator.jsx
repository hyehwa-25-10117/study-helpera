import React, { useState, useRef, useEffect } from "react";

// ============================================================
// BKT (Bayesian Knowledge Tracing) + 간격반복 간이 시뮬레이터
// 맞음/틀림 버튼을 누르면 "이 개념을 아는 확률"이 실시간으로 갱신된다.
// ============================================================

// --- BKT 파라미터 (조절 가능) ---
const DEFAULTS = {
  pL0: 0.3, // 초기 지식 (Prior): 배우기 전 이미 알 확률
  pT: 0.15, // 학습 확률 (Learn): 한 번 풀며 새로 알게 될 확률
  pG: 0.2, // 추측 확률 (Guess): 모르는데 찍어서 맞힐 확률
  pS: 0.1, // 실수 확률 (Slip): 아는데 실수로 틀릴 확률
};

const MASTERY = 0.95; // 숙달 기준

// 간격반복 스케줄(일). 잘 맞히면 다음 단계로, 틀리면 처음으로.
const INTERVALS = [1, 3, 7, 15, 30];

// BKT 업데이트 한 스텝
function bktUpdate(pLprev, correct, p) {
  // 1) 관찰(정답/오답)로 사후확률 계산 (베이즈 정리)
  let posterior;
  if (correct) {
    const num = pLprev * (1 - p.pS);
    const den = pLprev * (1 - p.pS) + (1 - pLprev) * p.pG;
    posterior = num / den;
  } else {
    const num = pLprev * p.pS;
    const den = pLprev * p.pS + (1 - pLprev) * (1 - p.pG);
    posterior = num / den;
  }
  // 2) 학습 반영: 풀면서 배웠을 가능성 추가
  const pLnew = posterior + (1 - posterior) * p.pT;
  return pLnew;
}

const TEAL = "#028090";
const SEAFOAM = "#00A896";
const MINT = "#02C39A";
const DARK = "#023436";
const CORAL = "#F96167";
const LIGHT = "#F2F7F6";
const GRAY = "#5A6B6A";

export default function BKTSimulator() {
  const [params, setParams] = useState(DEFAULTS);
  const [pL, setPL] = useState(DEFAULTS.pL0);
  const [history, setHistory] = useState([{ step: 0, pL: DEFAULTS.pL0, result: null }]);
  const [intervalIdx, setIntervalIdx] = useState(0);
  const [day, setDay] = useState(0);
  const [nextReview, setNextReview] = useState(INTERVALS[0]);
  const scrollRef = useRef(null);

  const mastered = pL >= MASTERY;

  function answer(correct) {
    const newPL = bktUpdate(pL, correct, params);
    setPL(newPL);
    const step = history.length;
    setHistory((h) => [...h, { step, pL: newPL, result: correct }]);

    // 간격반복: 맞으면 간격 늘리고, 틀리면 처음으로
    let idx = correct ? Math.min(intervalIdx + 1, INTERVALS.length - 1) : 0;
    setIntervalIdx(idx);
    const advanced = day + nextReview;
    setDay(advanced);
    setNextReview(INTERVALS[idx]);
  }

  function reset() {
    setPL(params.pL0);
    setHistory([{ step: 0, pL: params.pL0, result: null }]);
    setIntervalIdx(0);
    setDay(0);
    setNextReview(INTERVALS[0]);
  }

  // 파라미터 바뀌면 초기값도 리셋
  function updateParam(key, value) {
    const np = { ...params, [key]: value };
    setParams(np);
    if (key === "pL0") {
      // 초기지식 바뀌면 전체 리셋
    }
  }

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollLeft = scrollRef.current.scrollWidth;
  }, [history]);

  // --- 그래프 좌표 계산 ---
  const W = 640, H = 240, PAD = 34;
  const maxSteps = Math.max(history.length - 1, 8);
  const xFor = (i) => PAD + (i / maxSteps) * (W - PAD * 2);
  const yFor = (p) => PAD + (1 - p) * (H - PAD * 2);
  const pathD = history
    .map((pt, i) => `${i === 0 ? "M" : "L"} ${xFor(i).toFixed(1)} ${yFor(pt.pL).toFixed(1)}`)
    .join(" ");

  const sliderRows = [
    { key: "pL0", label: "초기 지식", sub: "배우기 전 알 확률", color: TEAL },
    { key: "pT", label: "학습 확률", sub: "풀며 새로 알게 될 확률", color: SEAFOAM },
    { key: "pG", label: "추측 확률", sub: "모르는데 찍어 맞힐 확률", color: MINT },
    { key: "pS", label: "실수 확률", sub: "아는데 틀릴 확률", color: CORAL },
  ];

  return (
    <div style={{ fontFamily: "'Segoe UI', 'Malgun Gothic', sans-serif", background: "#FFFFFF", color: DARK, minHeight: "100%", padding: "24px 20px", maxWidth: 900, margin: "0 auto" }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: TEAL, letterSpacing: 1, marginBottom: 4 }}>BKT + 간격반복 시뮬레이터</div>
        <h1 style={{ fontSize: 26, fontWeight: 800, margin: "0 0 6px", lineHeight: 1.2 }}>
          "이 개념을 아는 확률"이 어떻게 변할까?
        </h1>
        <p style={{ fontSize: 14, color: GRAY, margin: 0 }}>
          아래 <b>맞음 / 틀림</b> 버튼을 눌러보세요. 문제를 풀 때마다 확률이 실시간으로 갱신됩니다.
        </p>
      </div>

      {/* Big probability readout */}
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 18 }}>
        <div style={{ flex: "1 1 180px", background: mastered ? MINT : DARK, borderRadius: 16, padding: "18px 22px", color: "#fff", transition: "background .4s" }}>
          <div style={{ fontSize: 13, opacity: 0.85, marginBottom: 4 }}>P(안다) — 아는 확률</div>
          <div style={{ fontSize: 46, fontWeight: 800, lineHeight: 1 }}>{(pL * 100).toFixed(1)}<span style={{ fontSize: 22 }}>%</span></div>
          <div style={{ fontSize: 13, marginTop: 8, fontWeight: 700 }}>
            {mastered ? "숙달 완료! (95% 돌파)" : `숙달까지 ${((MASTERY - pL) * 100).toFixed(1)}%p 남음`}
          </div>
        </div>
        <div style={{ flex: "1 1 180px", background: LIGHT, borderRadius: 16, padding: "18px 22px" }}>
          <div style={{ fontSize: 13, color: GRAY, marginBottom: 4 }}>다음 복습 예약 (간격반복)</div>
          <div style={{ fontSize: 46, fontWeight: 800, lineHeight: 1, color: TEAL }}>{nextReview}<span style={{ fontSize: 20, color: GRAY }}>일 후</span></div>
          <div style={{ fontSize: 13, marginTop: 8, color: GRAY }}>
            누적 {day}일 · 복습 단계 {intervalIdx + 1}/{INTERVALS.length}
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div style={{ display: "flex", gap: 12, marginBottom: 22 }}>
        <button onClick={() => answer(true)} style={btn(MINT)}>
          ⭕ 맞음
        </button>
        <button onClick={() => answer(false)} style={btn(CORAL)}>
          ❌ 틀림
        </button>
        <button onClick={reset} style={{ ...btn("#fff"), color: GRAY, border: `2px solid #DDE6E4`, flex: "0 0 auto", padding: "0 20px" }}>
          초기화
        </button>
      </div>

      {/* Graph */}
      <div style={{ background: LIGHT, borderRadius: 16, padding: 16, marginBottom: 22 }}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 8 }}>확률 변화 그래프</div>
        <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: "auto", display: "block" }}>
          {/* mastery line */}
          <line x1={PAD} y1={yFor(MASTERY)} x2={W - PAD} y2={yFor(MASTERY)} stroke={MINT} strokeDasharray="5 4" strokeWidth="1.5" />
          <text x={W - PAD} y={yFor(MASTERY) - 6} fontSize="11" fill={MINT} textAnchor="end" fontWeight="700">숙달 95%</text>
          {/* axes */}
          <line x1={PAD} y1={PAD} x2={PAD} y2={H - PAD} stroke="#C9D6D4" strokeWidth="1" />
          <line x1={PAD} y1={H - PAD} x2={W - PAD} y2={H - PAD} stroke="#C9D6D4" strokeWidth="1" />
          <text x={PAD - 8} y={yFor(1) + 4} fontSize="10" fill={GRAY} textAnchor="end">100%</text>
          <text x={PAD - 8} y={yFor(0.5) + 4} fontSize="10" fill={GRAY} textAnchor="end">50%</text>
          <text x={PAD - 8} y={yFor(0) + 4} fontSize="10" fill={GRAY} textAnchor="end">0%</text>
          {/* line path */}
          <path d={pathD} fill="none" stroke={TEAL} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
          {/* points */}
          {history.map((pt, i) => (
            <circle key={i} cx={xFor(i)} cy={yFor(pt.pL)} r={i === history.length - 1 ? 5 : 3.5}
              fill={pt.result === null ? GRAY : pt.result ? MINT : CORAL} stroke="#fff" strokeWidth="1.5" />
          ))}
        </svg>
      </div>

      {/* History chips */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 8 }}>풀이 이력</div>
        <div ref={scrollRef} style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 6 }}>
          {history.slice(1).length === 0 && <span style={{ fontSize: 13, color: GRAY }}>아직 없습니다. 버튼을 눌러보세요.</span>}
          {history.slice(1).map((pt, i) => (
            <div key={i} style={{ flex: "0 0 auto", background: pt.result ? "#E6F7F1" : "#FDE9EA", borderRadius: 10, padding: "6px 10px", fontSize: 12, textAlign: "center", minWidth: 52 }}>
              <div style={{ fontWeight: 800, color: pt.result ? MINT : CORAL }}>{pt.result ? "맞음" : "틀림"}</div>
              <div style={{ color: GRAY, marginTop: 2 }}>{(pt.pL * 100).toFixed(0)}%</div>
            </div>
          ))}
        </div>
      </div>

      {/* Parameter sliders */}
      <div style={{ background: DARK, borderRadius: 16, padding: "18px 20px" }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: MINT, marginBottom: 4 }}>BKT 4가지 파라미터 조절</div>
        <div style={{ fontSize: 12, color: "#AFCFCC", marginBottom: 14 }}>값을 바꾸면 확률이 얼마나 민감하게 변하는지 실험할 수 있어요. (바꾼 뒤 초기화 권장)</div>
        {sliderRows.map((r) => (
          <div key={r.key} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
            <div style={{ flex: "0 0 130px" }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "#fff" }}>{r.label}</div>
              <div style={{ fontSize: 11, color: "#8FB4B0" }}>{r.sub}</div>
            </div>
            <input type="range" min="0" max="1" step="0.01" value={params[r.key]}
              onChange={(e) => updateParam(r.key, parseFloat(e.target.value))}
              style={{ flex: 1, accentColor: r.color }} />
            <div style={{ flex: "0 0 44px", textAlign: "right", fontSize: 14, fontWeight: 700, color: r.color }}>
              {params[r.key].toFixed(2)}
            </div>
          </div>
        ))}
      </div>

      {/* Footer note */}
      <p style={{ fontSize: 12, color: GRAY, marginTop: 18, lineHeight: 1.6 }}>
        <b>작동 원리:</b> 맞히면 베이즈 정리로 P(안다)를 올리고, 틀리면 내립니다. 그 뒤 '학습 확률'만큼 한 번 더 올려 "풀면서 배운 효과"를 반영합니다.
        간격반복은 맞히면 복습 간격을 <b>1→3→7→15→30일</b>로 늘리고, 틀리면 다시 1일로 되돌립니다.
      </p>
    </div>
  );
}

function btn(bg) {
  return {
    flex: 1,
    padding: "16px 0",
    fontSize: 17,
    fontWeight: 800,
    color: bg === "#fff" ? GRAY : "#fff",
    background: bg,
    border: "none",
    borderRadius: 14,
    cursor: "pointer",
    boxShadow: bg === "#fff" ? "none" : "0 4px 12px rgba(0,0,0,0.12)",
  };
}
